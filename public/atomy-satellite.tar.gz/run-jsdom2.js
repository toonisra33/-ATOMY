import { JSDOM } from 'jsdom';
JSDOM.fromURL("http://localhost:5000/", { runScripts: "dangerously", resources: "usable" }).then(dom => {
  dom.window.addEventListener("error", (event) => {
    console.error("DOM ERROR:", event.error || event.message);
  });
  setTimeout(() => {
    console.log("App rendered HTML length:", dom.window.document.body.innerHTML.length);
    process.exit(0);
  }, 2000);
});
